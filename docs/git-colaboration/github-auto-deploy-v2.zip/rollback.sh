#!/bin/bash
echo "⚠️ Rolling back to previous commit..."
git reset --hard $(cat .last_commit)
echo "✅ Rollback selesai."
