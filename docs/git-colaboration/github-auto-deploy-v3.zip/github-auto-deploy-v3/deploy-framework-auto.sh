#!/bin/bash

echo "🔍 Mendeteksi jenis project..."

if [ -f "package.json" ]; then
  echo "🟩 Project Node.js/JavaScript terdeteksi."
  npm install
  if [ -f "next.config.js" ]; then
    echo "📦 Next.js project"
    npm run build
  elif [ -f "vue.config.js" ]; then
    echo "📦 Vue.js project"
    npm run build
  else
    echo "📦 React or general Node.js project"
    npm run build
  fi

elif [ -f "composer.json" ]; then
  echo "🟦 Project PHP/Laravel terdeteksi."
  composer install --no-dev --optimize-autoloader
  php artisan migrate --force || echo '⚠️ Migrasi gagal, mungkin tidak diperlukan.'
  php artisan config:cache
  php artisan route:cache

elif [ -f "requirements.txt" ]; then
  echo "🐍 Python/Django project terdeteksi."
  pip install -r requirements.txt
  python manage.py migrate || echo '⚠️ Migrasi gagal, mungkin tidak diperlukan.'
  python manage.py collectstatic --noinput || echo '⚠️ Static file collection gagal, bisa jadi tidak diperlukan.'

else
  echo "❓ Tidak bisa mendeteksi framework. Silakan cek file konfigurasi Anda."
  exit 1
fi

echo "✅ Deploy selesai sesuai framework."
