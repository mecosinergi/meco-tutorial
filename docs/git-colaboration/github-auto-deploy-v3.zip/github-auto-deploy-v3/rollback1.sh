#!/bin/bash
echo "⚠️ Melakukan rollback ke commit sebelumnya..."
git reset --hard $(cat .last_commit)

echo "🔍 Mendeteksi framework untuk setup ulang..."

if [ -f "package.json" ]; then
  echo "🟩 Node.js terdeteksi - jalankan ulang build"
  npm install
  npm run build || echo "⚠️ Build gagal, silakan cek konfigurasi."

elif [ -f "composer.json" ]; then
  echo "🟦 Laravel terdeteksi - restore config"
  composer install --no-dev --optimize-autoloader
  php artisan config:cache
  php artisan route:cache
  php artisan migrate --force || echo "⚠️ Migrate gagal."

elif [ -f "requirements.txt" ]; then
  echo "🐍 Django terdeteksi - restore environment"
  pip install -r requirements.txt
  python manage.py migrate || echo "⚠️ Migrasi gagal."
  python manage.py collectstatic --noinput || echo "⚠️ Static collect gagal."

else
  echo "❓ Tidak diketahui framework-nya. Rollback selesai, tapi setup ulang tidak dilakukan."
fi

echo "✅ Rollback selesai."
